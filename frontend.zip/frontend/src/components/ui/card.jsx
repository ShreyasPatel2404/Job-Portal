import React from 'react';
import { cn } from '../../utils/cn';

export const Card = ({ className, ...props }) => (
  <div
    className={cn(
      'rounded-xl border border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm',
      className
    )}
    {...props}
  />
);

export const CardHeader = ({ className, ...props }) => (
  <div
    className={cn(
      'flex flex-col space-y-1.5 border-b border-gray-100 dark:border-zinc-800 px-6 py-4',
      className
    )}
    {...props}
  />
);

export const CardTitle = ({ className, ...props }) => (
  <h3
    className={cn(
      'text-base font-semibold leading-none tracking-tight text-gray-900 dark:text-gray-50',
      className
    )}
    {...props}
  />
);

export const CardDescription = ({ className, ...props }) => (
  <p
    className={cn(
      'text-sm text-gray-500 dark:text-gray-400',
      className
    )}
    {...props}
  />
);

export const CardContent = ({ className, ...props }) => (
  <div className={cn('px-6 py-4', className)} {...props} />
);

export const CardFooter = ({ className, ...props }) => (
  <div
    className={cn(
      'flex items-center justify-between px-6 py-4 border-t border-gray-100 dark:border-zinc-800',
      className
    )}
    {...props}
  />
);


