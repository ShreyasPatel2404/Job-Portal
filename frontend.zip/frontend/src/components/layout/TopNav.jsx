import React from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Briefcase, Sparkles, Bell, User, Menu } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/button';
import { cn } from '../../utils/cn';

// Top navigation used for marketing + seeker experience
export const TopNav = ({ onOpenMobileNav }) => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isRecruiter = user?.accountType === 'EMPLOYER';
  const isAdmin = user?.accountType === 'ADMIN';
  const isSeeker = user?.accountType === 'APPLICANT';

  return (
    <header className="sticky top-0 z-30 border-b border-gray-200 bg-white/90 backdrop-blur-md dark:bg-zinc-950/90 dark:border-zinc-800">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        {/* Brand */}
        <Link
          to="/"
          className="flex items-center gap-2 text-lg font-semibold tracking-tight text-gray-900 dark:text-gray-50"
        >
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-primary-600 text-white shadow-sm">
            <Briefcase className="h-4 w-4" aria-hidden="true" />
          </span>
          <span className="hidden sm:inline-flex">
            AI Job Portal
          </span>
        </Link>

        {/* Primary nav - desktop */}
        <nav className="hidden items-center gap-6 text-sm font-medium text-gray-600 dark:text-gray-300 md:flex">
          <NavLink
            to="/jobs"
            className={({ isActive }) =>
              cn(
                'transition-colors hover:text-gray-900 dark:hover:text-white',
                isActive && 'text-gray-900 dark:text-white'
              )
            }
          >
            Jobs
          </NavLink>

          {isSeeker && (
            <NavLink
              to="/applications"
              className={({ isActive }) =>
                cn(
                  'transition-colors hover:text-gray-900 dark:hover:text-white',
                  isActive && 'text-gray-900 dark:text-white'
                )
              }
            >
              Applications
            </NavLink>
          )}

          {isRecruiter && (
            <NavLink
              to="/dashboard/recruiter"
              className={({ isActive }) =>
                cn(
                  'transition-colors hover:text-gray-900 dark:hover:text-white',
                  isActive && 'text-gray-900 dark:text-white'
                )
              }
            >
              Recruiter
            </NavLink>
          )}

          {isAdmin && (
            <NavLink
              to="/dashboard/admin"
              className={({ isActive }) =>
                cn(
                  'transition-colors hover:text-gray-900 dark:hover:text-white',
                  isActive && 'text-gray-900 dark:text-white'
                )
              }
            >
              Admin
            </NavLink>
          )}
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-3">
          {isAuthenticated && (
            <>
              <NavLink
                to="/notifications"
                className="hidden rounded-full border border-gray-200 bg-white p-1.5 text-gray-500 shadow-sm transition hover:bg-gray-50 hover:text-gray-800 dark:border-zinc-800 dark:bg-zinc-900 dark:text-gray-300 dark:hover:bg-zinc-800 md:inline-flex"
                aria-label="Notifications"
              >
                <Bell className="h-4 w-4" aria-hidden="true" />
              </NavLink>

              <NavLink
                to={isSeeker ? '/dashboard/jobseeker' : isRecruiter ? '/dashboard/recruiter' : isAdmin ? '/dashboard/admin' : '/profile'}
                className="hidden items-center gap-1 rounded-full border border-gray-200 bg-white px-2.5 py-1 text-xs font-medium text-gray-700 shadow-sm transition hover:bg-gray-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-gray-200 dark:hover:bg-zinc-800 md:inline-flex"
              >
                <User className="h-3.5 w-3.5" aria-hidden="true" />
                <span className="max-w-[120px] truncate">
                  {user?.fullName || user?.email || 'Account'}
                </span>
              </NavLink>

              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="hidden md:inline-flex"
              >
                Sign out
              </Button>
            </>
          )}

          {!isAuthenticated && (
            <>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/login')}
              >
                Log in
              </Button>
              <Button
                size="sm"
                onClick={() => navigate('/register')}
                className="hidden sm:inline-flex"
              >
                <Sparkles className="mr-1.5 h-4 w-4" aria-hidden="true" />
                Sign up
              </Button>
            </>
          )}

          {/* Mobile menu trigger */}
          <button
            type="button"
            onClick={onOpenMobileNav}
            className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-gray-200 bg-white text-gray-600 shadow-sm transition hover:bg-gray-50 hover:text-gray-900 dark:border-zinc-800 dark:bg-zinc-900 dark:text-gray-200 dark:hover:bg-zinc-800 md:hidden"
            aria-label="Open navigation menu"
          >
            <Menu className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>
    </header>
  );
};


